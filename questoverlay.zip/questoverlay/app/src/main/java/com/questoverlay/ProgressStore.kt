package com.questoverlay

import android.content.Context
import android.content.SharedPreferences

/** Remembers quest progress, ticked items, overlay position and opacity. */
class ProgressStore(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    var activeQuestId: String?
        get() = prefs.getString(KEY_ACTIVE, null)
        set(value) {
            prefs.edit().putString(KEY_ACTIVE, value).apply()
        }

    var opacity: Float
        get() = prefs.getFloat(KEY_OPACITY, 0.92f).coerceIn(0.4f, 1f)
        set(value) {
            prefs.edit().putFloat(KEY_OPACITY, value.coerceIn(0.4f, 1f)).apply()
        }

    val overlayX: Int?
        get() = if (prefs.contains(KEY_X)) prefs.getInt(KEY_X, 0) else null

    val overlayY: Int?
        get() = if (prefs.contains(KEY_Y)) prefs.getInt(KEY_Y, 0) else null

    fun savePosition(x: Int, y: Int) {
        prefs.edit().putInt(KEY_X, x).putInt(KEY_Y, y).apply()
    }

    /** Index of the step you are on. Equal to the step count once the quest is finished. */
    fun stepIndex(questId: String): Int = prefs.getInt("step_$questId", 0)

    fun setStepIndex(questId: String, index: Int) {
        prefs.edit().putInt("step_$questId", index).apply()
    }

    fun checkedItems(questId: String): Set<Int> {
        val raw = prefs.getStringSet("items_$questId", null) ?: return emptySet()
        return raw.mapNotNull { it.toIntOrNull() }.toSet()
    }

    fun setItemChecked(questId: String, index: Int, checked: Boolean) {
        val current = checkedItems(questId).toMutableSet()
        if (checked) current.add(index) else current.remove(index)
        prefs.edit()
            .putStringSet("items_$questId", current.map { it.toString() }.toSet())
            .apply()
    }

    fun reset(questId: String) {
        prefs.edit().remove("step_$questId").remove("items_$questId").apply()
    }

    private companion object {
        const val FILE = "quest_progress"
        const val KEY_ACTIVE = "active_quest"
        const val KEY_OPACITY = "opacity"
        const val KEY_X = "overlay_x"
        const val KEY_Y = "overlay_y"
    }
}
