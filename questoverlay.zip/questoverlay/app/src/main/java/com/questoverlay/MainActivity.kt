package com.questoverlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

/** Quest picker and settings. Pick a quest, start the overlay, then switch to the game. */
class MainActivity : Activity() {

    private lateinit var store: ProgressStore
    private lateinit var content: LinearLayout
    private var quests: List<Quest> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = ProgressStore(this)
        quests = try {
            QuestRepository.load(this)
        } catch (e: Exception) {
            emptyList()
        }

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.SCREEN_BG)
        scroll.clipToPadding = false
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        scroll.addView(
            content,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        setContentView(scroll)

        // Android 15+ draws apps edge to edge, so keep the content clear of the system bars.
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        if (savedInstanceState == null) requestNotificationPermission()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
    }

    // ---------------------------------------------------------------- screen

    private fun refresh() {
        content.removeAllViews()
        val pad = Ui.dp(this, 16)
        content.setPadding(pad, pad, pad, pad)

        content.addView(Ui.text(this, "Quest Overlay", 28f, Ui.GOLD, bold = true))
        val intro = Ui.text(
            this,
            "A floating OSRS quest helper. It never touches the game: you tick steps off yourself.",
            13f,
            Ui.TAN
        )
        intro.setPadding(0, Ui.dp(this, 2), 0, Ui.dp(this, 14))
        content.addView(intro)

        content.addView(permissionCard())
        content.addView(opacityCard())

        val heading = Ui.text(this, "Quests", 18f, Ui.TEXT, bold = true)
        heading.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 6))
        content.addView(heading)

        if (quests.isEmpty()) {
            content.addView(Ui.text(this, "Could not load quests.json from the app.", 14f, Ui.RED))
        }
        for (q in quests) content.addView(questCard(q))

        content.addView(spaced(Ui.button(this, "Open Old School RuneScape", false) { launchGame() }, 16))
        content.addView(spaced(Ui.button(this, "Stop overlay", false) { stopOverlay() }, 8))

        val credit = Ui.text(
            this,
            "Quest data adapted from the Old School RuneScape Wiki (CC BY-NC-SA 3.0). " +
                "Not affiliated with Jagex. Directions are rough, so trust your map over the compass.",
            11f,
            Ui.MUTED
        )
        credit.setPadding(0, Ui.dp(this, 18), 0, Ui.dp(this, 8))
        content.addView(credit)
    }

    private fun spaced(view: View, topDp: Int): View {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, topDp)
        view.layoutParams = lp
        return view
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val p = Ui.dp(this, 14)
        c.setPadding(p, p, p, p)
        c.background = Ui.rounded(this, Ui.CARD_BG, 14, Ui.STROKE, 1)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 8)
        c.layoutParams = lp
        return c
    }

    private fun permissionCard(): View {
        val c = card()
        if (Settings.canDrawOverlays(this)) {
            c.addView(Ui.text(this, "Overlay permission granted ✓", 14f, Ui.GREEN, bold = true))
        } else {
            c.addView(Ui.text(this, "Overlay permission needed", 14f, Ui.RED, bold = true))
            val why = Ui.text(
                this,
                "Android needs you to allow \"Display over other apps\" so the card can sit on top of the game.",
                12f,
                Ui.TEXT
            )
            why.setPadding(0, Ui.dp(this, 4), 0, 0)
            c.addView(why)
            c.addView(spaced(Ui.button(this, "Grant permission", true) { openOverlaySettings() }, 10))
        }
        return c
    }

    private fun opacityCard(): View {
        val c = card()
        val percent = (store.opacity * 100f).roundToInt()
        val label = Ui.text(this, "Overlay opacity: $percent%", 14f, Ui.TEXT, bold = true)
        c.addView(label)

        val seek = SeekBar(this)
        seek.max = 60
        seek.progress = percent - 40
        seek.progressTintList = ColorStateList.valueOf(Ui.GOLD)
        seek.thumbTintList = ColorStateList.valueOf(Ui.GOLD)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                val value = progress + 40
                label.text = "Overlay opacity: $value%"
                if (fromUser) store.opacity = value / 100f
            }

            override fun onStartTrackingTouch(bar: SeekBar) {}

            override fun onStopTrackingTouch(bar: SeekBar) {
                refreshOverlay()
            }
        })
        c.addView(seek)
        return c
    }

    private fun questCard(q: Quest): View {
        val step = store.stepIndex(q.id).coerceIn(0, q.steps.size)
        val c = card()
        val isActive = OverlayService.running && store.activeQuestId == q.id
        if (isActive) c.background = Ui.rounded(this, Ui.CARD_BG, 14, Ui.GOLD, 2)

        c.addView(Ui.text(this, q.name, 17f, Ui.GOLD, bold = true))
        val meta = Ui.text(this, "${q.difficulty} · ${q.length} · ${q.steps.size} steps", 12f, Ui.TAN)
        c.addView(meta)

        val status = when {
            step >= q.steps.size -> "Complete ✓"
            step == 0 -> "Not started"
            else -> "In progress: step ${step + 1} of ${q.steps.size}"
        }
        val statusColor = if (step >= q.steps.size) Ui.GREEN else Ui.TEXT
        val statusView = Ui.text(this, status, 13f, statusColor)
        statusView.setPadding(0, Ui.dp(this, 6), 0, 0)
        c.addView(statusView)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        val start = Ui.button(this, if (isActive) "Showing" else "Start overlay", !isActive) { startOverlay(q) }
        val reset = Ui.button(this, "Reset", false) {
            store.reset(q.id)
            refreshOverlay()
            refresh()
        }
        buttons.addView(start, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
        val resetLp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        resetLp.leftMargin = Ui.dp(this, 8)
        buttons.addView(reset, resetLp)
        c.addView(spaced(buttons, 10))
        return c
    }

    // ---------------------------------------------------------------- actions

    private fun openOverlaySettings() {
        val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        startActivity(intent)
    }

    private fun startOverlay(q: Quest) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant the overlay permission first.", Toast.LENGTH_LONG).show()
            openOverlaySettings()
            return
        }
        store.activeQuestId = q.id
        val intent = Intent(this, OverlayService::class.java)
        intent.putExtra(OverlayService.EXTRA_QUEST_ID, q.id)
        startForegroundService(intent)
        Toast.makeText(
            this,
            "Overlay started. Open the game, then drag the card by its title.",
            Toast.LENGTH_LONG
        ).show()
        refresh()
    }

    private fun stopOverlay() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        }
        // The service takes a moment to shut down, so redraw after it has.
        content.postDelayed({ refresh() }, 400)
    }

    /** Tells a running overlay to redraw (opacity or progress changed). */
    private fun refreshOverlay() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_REFRESH))
        }
    }

    private fun launchGame() {
        val intent = packageManager.getLaunchIntentForPackage(OSRS_PACKAGE)
        if (intent == null) {
            Toast.makeText(this, "Couldn't find the game. Open it from your app list.", Toast.LENGTH_LONG).show()
        } else {
            startActivity(intent)
        }
    }

    private companion object {
        const val REQUEST_NOTIFICATIONS = 100
        const val OSRS_PACKAGE = "com.jagex.oldscape.android"
    }
}
