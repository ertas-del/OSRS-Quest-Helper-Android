package com.questoverlay

import android.content.Context
import org.json.JSONObject

/** Direction of travel for a step. The first eight are compass bearings. */
enum class Dir(val key: String, val label: String, val degrees: Float) {
    N("N", "Head north", 0f),
    NE("NE", "Head north-east", 45f),
    E("E", "Head east", 90f),
    SE("SE", "Head south-east", 135f),
    S("S", "Head south", 180f),
    SW("SW", "Head south-west", 225f),
    W("W", "Head west", 270f),
    NW("NW", "Head north-west", 315f),
    UP("UP", "Climb up", -1f),
    DOWN("DOWN", "Climb down", -1f),
    HERE("HERE", "You are in the right spot", -1f),
    NONE("NONE", "", -1f);

    val isCompass: Boolean get() = degrees >= 0f

    companion object {
        fun from(key: String?): Dir =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: NONE
    }
}

data class Item(val name: String, val qty: Int, val note: String) {
    val label: String get() = if (qty > 1) "$qty× $name" else name
}

data class Step(val text: String, val where: String, val dir: Dir, val hint: String)

data class Quest(
    val id: String,
    val name: String,
    val difficulty: String,
    val length: String,
    val requirements: String,
    val wikiUrl: String,
    val tip: String,
    val items: List<Item>,
    val steps: List<Step>
)

object QuestRepository {

    fun load(context: Context): List<Quest> {
        val text = context.assets.open("quests.json").bufferedReader().use { it.readText() }
        val quests = JSONObject(text).getJSONArray("quests")
        val result = ArrayList<Quest>(quests.length())
        for (i in 0 until quests.length()) {
            result.add(parseQuest(quests.getJSONObject(i)))
        }
        return result
    }

    private fun parseQuest(o: JSONObject): Quest {
        val items = ArrayList<Item>()
        val itemArray = o.optJSONArray("items")
        if (itemArray != null) {
            for (i in 0 until itemArray.length()) {
                val io = itemArray.getJSONObject(i)
                items.add(Item(io.getString("name"), io.optInt("qty", 1), io.optString("note", "")))
            }
        }
        val steps = ArrayList<Step>()
        val stepArray = o.getJSONArray("steps")
        for (i in 0 until stepArray.length()) {
            val so = stepArray.getJSONObject(i)
            steps.add(
                Step(
                    text = so.getString("text"),
                    where = so.optString("where", ""),
                    dir = Dir.from(so.optString("dir", "NONE")),
                    hint = so.optString("hint", "")
                )
            )
        }
        return Quest(
            id = o.getString("id"),
            name = o.getString("name"),
            difficulty = o.optString("difficulty", ""),
            length = o.optString("length", ""),
            requirements = o.optString("requirements", "None"),
            wikiUrl = o.optString("wikiUrl", ""),
            tip = o.optString("tip", ""),
            items = items,
            steps = steps
        )
    }
}
